"""Integer pixel predicates used by the blue/green PL color module."""
import numpy as np


def mask_from_bgr(image, mode='green'):
    b,g,r=[image[:,:,i].astype(np.int32) for i in range(3)]
    high=np.maximum(np.maximum(r,g),b)
    low=np.minimum(np.minimum(r,g),b)
    delta=high-low
    green=(high>=45)&(delta>0)&(delta*255>=high*35)&(
        ((g>=r)&(g>=b)&((r<=b)|((r-b)*6<=delta*5)))|
        ((b>g)&(g>=r)&((g-r)*6>=delta*5)))
    y=(4899*r+9617*g+1868*b+8192)>>14
    blue=b-y>=40
    if mode=='green':hit=green
    elif mode=='blue':hit=blue
    elif mode=='both':hit=green|blue
    else:raise ValueError(mode)
    return hit.astype(np.uint8)*255

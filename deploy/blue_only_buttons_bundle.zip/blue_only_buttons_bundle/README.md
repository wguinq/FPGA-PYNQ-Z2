# Blue plate only with three buttons

Copy the complete folder to the board. Connect the monitor to HDMI OUT
and set SW0 down for camera display.

    cd ~/blue_only_buttons_bundle
    sha256sum -c SHA256SUMS
    python3 run_plate.py

The default launcher selects adaptive_pl (PL Cb150 blue proposals), the
original TinyPlateCTC model, and all three board buttons.

- BTN0 captures the current camera and display frames and result metadata.
- BTN1 pauses or resumes detection.
- BTN2 toggles between the camera view and the top candidate's binary image.

Use python3 run_plate.py preview for camera only. Use --frames 600 for a
bounded test. Use --debug to save diagnostics. Detection logs go under runs/.
The bit/HWH are the existing three-button build. Board validation is pending.

Boxes are sent before OCR. Detector startup milestones are printed once.
